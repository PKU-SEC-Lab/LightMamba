
wire kernel_monitor_reset;
wire kernel_monitor_clock;
assign kernel_monitor_reset = ~ap_rst_n;
assign kernel_monitor_clock = ap_clk;
wire [5:0] axis_block_sigs;
wire [2:0] inst_idle_sigs;
wire [0:0] inst_block_sigs;
wire kernel_block;

assign axis_block_sigs[0] = ~grp_top_Pipeline_VITIS_LOOP_83_1_VITIS_LOOP_85_3_VITIS_LOOP_86_4_fu_38.qk_stream_TDATA_blk_n;
assign axis_block_sigs[1] = ~grp_top_Pipeline_VITIS_LOOP_83_1_VITIS_LOOP_85_3_VITIS_LOOP_86_4_fu_38.gemm_stream_TDATA_blk_n;
assign axis_block_sigs[2] = ~grp_top_Pipeline_VITIS_LOOP_83_1_VITIS_LOOP_85_3_VITIS_LOOP_86_4_fu_38.v_stream_TDATA_blk_n;
assign axis_block_sigs[3] = ~grp_top_Pipeline_VITIS_LOOP_104_6_fu_48.od_stream_TDATA_blk_n;
assign axis_block_sigs[4] = ~grp_top_Pipeline_VITIS_LOOP_104_6_fu_48.gemm_stream_TDATA_blk_n;
assign axis_block_sigs[5] = ~grp_top_Pipeline_VITIS_LOOP_104_6_fu_48.ug_stream_TDATA_blk_n;

assign inst_block_sigs[0] = 1'b0;

assign inst_idle_sigs[0] = 1'b0;
assign inst_idle_sigs[1] = grp_top_Pipeline_VITIS_LOOP_83_1_VITIS_LOOP_85_3_VITIS_LOOP_86_4_fu_38.ap_idle;
assign inst_idle_sigs[2] = grp_top_Pipeline_VITIS_LOOP_104_6_fu_48.ap_idle;

top_hls_deadlock_idx0_monitor top_hls_deadlock_idx0_monitor_U (
    .clock(kernel_monitor_clock),
    .reset(kernel_monitor_reset),
    .axis_block_sigs(axis_block_sigs),
    .inst_idle_sigs(inst_idle_sigs),
    .inst_block_sigs(inst_block_sigs),
    .block(kernel_block)
);

always @ (kernel_block or kernel_monitor_reset) begin
    if (kernel_block == 1'b1 && kernel_monitor_reset == 1'b0) begin
        find_kernel_block = 1'b1;
    end
    else begin
        find_kernel_block = 1'b0;
    end
end
