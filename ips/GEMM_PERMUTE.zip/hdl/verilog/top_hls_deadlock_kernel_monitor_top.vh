
wire kernel_monitor_reset;
wire kernel_monitor_clock;
assign kernel_monitor_reset = ~ap_rst_n;
assign kernel_monitor_clock = ap_clk;
wire [5:0] axis_block_sigs;
wire [9:0] inst_idle_sigs;
wire [3:0] inst_block_sigs;
wire kernel_block;

assign axis_block_sigs[0] = ~do_tensor_core_U0.i_stream_TDATA_blk_n;
assign axis_block_sigs[1] = ~do_tensor_core_U0.w_stream_TDATA_blk_n;
assign axis_block_sigs[2] = ~do_accumulator_U0.stage1_accumulation_U0.s_stream_TDATA_blk_n;
assign axis_block_sigs[3] = ~do_accumulator_U0.stage1_accumulation_U0.s1_stream_TDATA_blk_n;
assign axis_block_sigs[4] = ~do_accumulator_U0.stage1_accumulation_U0.s2_stream_TDATA_blk_n;
assign axis_block_sigs[5] = ~do_accumulator_U0.stage2_unpack_U0.grp_stage2_unpack_Pipeline_1_fu_564.o_stream_TDATA_blk_n;

assign inst_idle_sigs[0] = do_tensor_core_U0.ap_idle;
assign inst_block_sigs[0] = (do_tensor_core_U0.ap_done & ~do_tensor_core_U0.ap_continue) | ~do_accumulator_U0.stage1_accumulation_U0.gemm_stream_blk_n | ~do_accumulator_U0.stage1_accumulation_U0.o1_stream_blk_n | ~do_accumulator_U0.stage1_accumulation_U0.o2_stream_blk_n;
assign inst_idle_sigs[1] = do_accumulator_U0.ap_idle;
assign inst_block_sigs[1] = (do_accumulator_U0.ap_done & ~do_accumulator_U0.ap_continue) | ~do_accumulator_U0.stage2_unpack_U0.o1_stream_blk_n | ~do_accumulator_U0.stage2_unpack_U0.o2_stream_blk_n;
assign inst_idle_sigs[2] = do_accumulator_U0.stage1_accumulation_U0.ap_idle;
assign inst_block_sigs[2] = (do_accumulator_U0.stage1_accumulation_U0.ap_done & ~do_accumulator_U0.stage1_accumulation_U0.ap_continue) | ~do_tensor_core_U0.gemm_stream_blk_n;
assign inst_idle_sigs[3] = do_accumulator_U0.stage2_unpack_U0.ap_idle;
assign inst_block_sigs[3] = (do_accumulator_U0.stage2_unpack_U0.ap_done & ~do_accumulator_U0.stage2_unpack_U0.ap_continue) | ~do_accumulator_U0.stage1_accumulation_U0.gemm_stream_blk_n;

assign inst_idle_sigs[4] = 1'b0;
assign inst_idle_sigs[5] = do_tensor_core_U0.ap_idle;
assign inst_idle_sigs[6] = do_accumulator_U0.ap_idle;
assign inst_idle_sigs[7] = do_accumulator_U0.stage1_accumulation_U0.ap_idle;
assign inst_idle_sigs[8] = do_accumulator_U0.stage2_unpack_U0.ap_idle;
assign inst_idle_sigs[9] = do_accumulator_U0.stage2_unpack_U0.grp_stage2_unpack_Pipeline_1_fu_564.ap_idle;

top_hls_deadlock_idx0_monitor top_hls_deadlock_idx0_monitor_U (
    .clock(kernel_monitor_clock),
    .reset(kernel_monitor_reset),
    .axis_block_sigs(axis_block_sigs),
    .inst_idle_sigs(inst_idle_sigs),
    .inst_block_sigs(inst_block_sigs),
    .block(kernel_block)
);

always @ (kernel_block or kernel_monitor_reset) begin
    if (kernel_block == 1'b1 && kernel_monitor_reset == 1'b0) begin
        find_kernel_block = 1'b1;
    end
    else begin
        find_kernel_block = 1'b0;
    end
end
