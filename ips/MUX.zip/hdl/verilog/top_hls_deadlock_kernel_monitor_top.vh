
wire kernel_monitor_reset;
wire kernel_monitor_clock;
assign kernel_monitor_reset = ~ap_rst_n;
assign kernel_monitor_clock = ap_clk;
wire [7:0] axis_block_sigs;
wire [20:0] inst_idle_sigs;
wire [9:0] inst_block_sigs;
wire kernel_block;

assign axis_block_sigs[0] = ~XLN_DEMUX_U0.xlnq_stream_TDATA_blk_n;
assign axis_block_sigs[1] = ~XLN_DEMUX_U0.xlns_stream_TDATA_blk_n;
assign axis_block_sigs[2] = ~do_buffer_merge_1_U0.grp_do_buffer_merge_1_Pipeline_1_fu_60.aq_stream_TDATA_blk_n;
assign axis_block_sigs[3] = ~do_buffer_merge_U0.grp_do_buffer_merge_Pipeline_1_fu_60.as_stream_TDATA_blk_n;
assign axis_block_sigs[4] = ~do_buffer_unpack_1_U0.grp_do_buffer_unpack_1_Pipeline_1_fu_60.xmq_stream_TDATA_blk_n;
assign axis_block_sigs[5] = ~do_buffer_unpack_U0.grp_do_buffer_unpack_Pipeline_1_fu_60.xms_stream_TDATA_blk_n;
assign axis_block_sigs[6] = ~GEMM_MUX_U0.q_stream_TDATA_blk_n;
assign axis_block_sigs[7] = ~GEMM_MUX_U0.s_stream_TDATA_blk_n;

assign inst_idle_sigs[0] = XLN_DEMUX_U0.ap_idle;
assign inst_block_sigs[0] = (XLN_DEMUX_U0.ap_done & ~XLN_DEMUX_U0.ap_continue) | ~XLN_DEMUX_U0.mha_xlnq_stream_blk_n | ~XLN_DEMUX_U0.mha_xlns_stream_blk_n | ~XLN_DEMUX_U0.mlp_xlnq_stream_blk_n | ~XLN_DEMUX_U0.mlp_xlns_stream_blk_n;
assign inst_idle_sigs[1] = do_buffer_1_1_U0.ap_idle;
assign inst_block_sigs[1] = (do_buffer_1_1_U0.ap_done & ~do_buffer_1_1_U0.ap_continue) | ~do_buffer_1_1_U0.grp_do_buffer_1_1_Pipeline_1_fu_54.mha_xlnq_stream_blk_n | ~do_buffer_1_1_U0.grp_do_buffer_1_1_Pipeline_2_fu_76.mha_xlnq_buffered_stream_blk_n;
assign inst_idle_sigs[2] = do_buffer_U0.ap_idle;
assign inst_block_sigs[2] = (do_buffer_U0.ap_done & ~do_buffer_U0.ap_continue) | ~do_buffer_U0.grp_do_buffer_Pipeline_1_fu_54.mha_xlns_stream_blk_n | ~do_buffer_U0.grp_do_buffer_Pipeline_2_fu_76.mha_xlns_buffered_stream_blk_n;
assign inst_idle_sigs[3] = do_buffer_merge_1_U0.ap_idle;
assign inst_block_sigs[3] = (do_buffer_merge_1_U0.ap_done & ~do_buffer_merge_1_U0.ap_continue) | ~do_buffer_merge_1_U0.grp_do_buffer_merge_1_Pipeline_2_fu_74.aq_buffered_stream_blk_n;
assign inst_idle_sigs[4] = do_buffer_merge_U0.ap_idle;
assign inst_block_sigs[4] = (do_buffer_merge_U0.ap_done & ~do_buffer_merge_U0.ap_continue) | ~do_buffer_merge_U0.grp_do_buffer_merge_Pipeline_2_fu_74.as_buffered_stream_blk_n;
assign inst_idle_sigs[5] = do_buffer_1_U0.ap_idle;
assign inst_block_sigs[5] = (do_buffer_1_U0.ap_done & ~do_buffer_1_U0.ap_continue) | ~do_buffer_1_U0.grp_do_buffer_1_Pipeline_1_fu_54.mlp_xlnq_stream_blk_n | ~do_buffer_1_U0.grp_do_buffer_1_Pipeline_2_fu_76.mlp_xlnq_buffered_stream_blk_n;
assign inst_idle_sigs[6] = do_buffer_2_U0.ap_idle;
assign inst_block_sigs[6] = (do_buffer_2_U0.ap_done & ~do_buffer_2_U0.ap_continue) | ~do_buffer_2_U0.grp_do_buffer_2_Pipeline_1_fu_54.mlp_xlns_stream_blk_n | ~do_buffer_2_U0.grp_do_buffer_2_Pipeline_2_fu_76.mlp_xlns_buffered_stream_blk_n;
assign inst_idle_sigs[7] = do_buffer_unpack_1_U0.ap_idle;
assign inst_block_sigs[7] = (do_buffer_unpack_1_U0.ap_done & ~do_buffer_unpack_1_U0.ap_continue) | ~do_buffer_unpack_1_U0.grp_do_buffer_unpack_1_Pipeline_2_fu_74.xmq_buffered_stream_blk_n;
assign inst_idle_sigs[8] = do_buffer_unpack_U0.ap_idle;
assign inst_block_sigs[8] = (do_buffer_unpack_U0.ap_done & ~do_buffer_unpack_U0.ap_continue) | ~do_buffer_unpack_U0.grp_do_buffer_unpack_Pipeline_2_fu_74.xms_buffered_stream_blk_n;
assign inst_idle_sigs[9] = GEMM_MUX_U0.ap_idle;
assign inst_block_sigs[9] = (GEMM_MUX_U0.ap_done & ~GEMM_MUX_U0.ap_continue) | ~GEMM_MUX_U0.mha_xlnq_buffered_stream_blk_n | ~GEMM_MUX_U0.mha_xlns_buffered_stream_blk_n | ~GEMM_MUX_U0.aq_buffered_stream_blk_n | ~GEMM_MUX_U0.as_buffered_stream_blk_n | ~GEMM_MUX_U0.mlp_xlnq_buffered_stream_blk_n | ~GEMM_MUX_U0.mlp_xlns_buffered_stream_blk_n | ~GEMM_MUX_U0.xmq_buffered_stream_blk_n | ~GEMM_MUX_U0.xms_buffered_stream_blk_n;

assign inst_idle_sigs[10] = 1'b0;
assign inst_idle_sigs[11] = XLN_DEMUX_U0.ap_idle;
assign inst_idle_sigs[12] = do_buffer_merge_1_U0.ap_idle;
assign inst_idle_sigs[13] = do_buffer_merge_1_U0.grp_do_buffer_merge_1_Pipeline_1_fu_60.ap_idle;
assign inst_idle_sigs[14] = do_buffer_merge_U0.ap_idle;
assign inst_idle_sigs[15] = do_buffer_merge_U0.grp_do_buffer_merge_Pipeline_1_fu_60.ap_idle;
assign inst_idle_sigs[16] = do_buffer_unpack_1_U0.ap_idle;
assign inst_idle_sigs[17] = do_buffer_unpack_1_U0.grp_do_buffer_unpack_1_Pipeline_1_fu_60.ap_idle;
assign inst_idle_sigs[18] = do_buffer_unpack_U0.ap_idle;
assign inst_idle_sigs[19] = do_buffer_unpack_U0.grp_do_buffer_unpack_Pipeline_1_fu_60.ap_idle;
assign inst_idle_sigs[20] = GEMM_MUX_U0.ap_idle;

top_hls_deadlock_idx0_monitor top_hls_deadlock_idx0_monitor_U (
    .clock(kernel_monitor_clock),
    .reset(kernel_monitor_reset),
    .axis_block_sigs(axis_block_sigs),
    .inst_idle_sigs(inst_idle_sigs),
    .inst_block_sigs(inst_block_sigs),
    .block(kernel_block)
);

always @ (kernel_block or kernel_monitor_reset) begin
    if (kernel_block == 1'b1 && kernel_monitor_reset == 1'b0) begin
        find_kernel_block = 1'b1;
    end
    else begin
        find_kernel_block = 1'b0;
    end
end
