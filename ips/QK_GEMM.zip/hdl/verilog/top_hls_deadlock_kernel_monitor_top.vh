
wire kernel_monitor_reset;
wire kernel_monitor_clock;
assign kernel_monitor_reset = ~ap_rst_n;
assign kernel_monitor_clock = ap_clk;
wire [2:0] axis_block_sigs;
wire [21:0] inst_idle_sigs;
wire [16:0] inst_block_sigs;
wire kernel_block;

assign axis_block_sigs[0] = ~grp_do_qk_gemm_fu_30.split_interleaved_heads_ap_int_6_32_32_1_128_8_U0.qk_q_stream_TDATA_blk_n;
assign axis_block_sigs[1] = ~grp_do_qk_gemm_fu_30.split_interleaved_heads_ap_uint_4_32_32_1_16_1_U0.qk_s_stream_TDATA_blk_n;
assign axis_block_sigs[2] = ~grp_do_qk_gemm_fu_30.do_bmm_U0.r_stream_TDATA_blk_n;

assign inst_idle_sigs[0] = grp_do_qk_gemm_fu_30.split_interleaved_heads_ap_int_6_32_32_1_128_8_U0.ap_idle;
assign inst_block_sigs[0] = (grp_do_qk_gemm_fu_30.split_interleaved_heads_ap_int_6_32_32_1_128_8_U0.ap_done & ~grp_do_qk_gemm_fu_30.split_interleaved_heads_ap_int_6_32_32_1_128_8_U0.ap_continue) | ~grp_do_qk_gemm_fu_30.split_interleaved_heads_ap_int_6_32_32_1_128_8_U0.qq_stream_blk_n | ~grp_do_qk_gemm_fu_30.split_interleaved_heads_ap_int_6_32_32_1_128_8_U0.kq_stream_blk_n;
assign inst_idle_sigs[1] = grp_do_qk_gemm_fu_30.split_interleaved_heads_ap_uint_4_32_32_1_16_1_U0.ap_idle;
assign inst_block_sigs[1] = (grp_do_qk_gemm_fu_30.split_interleaved_heads_ap_uint_4_32_32_1_16_1_U0.ap_done & ~grp_do_qk_gemm_fu_30.split_interleaved_heads_ap_uint_4_32_32_1_16_1_U0.ap_continue) | ~grp_do_qk_gemm_fu_30.split_interleaved_heads_ap_uint_4_32_32_1_16_1_U0.qs_stream_blk_n | ~grp_do_qk_gemm_fu_30.split_interleaved_heads_ap_uint_4_32_32_1_16_1_U0.ks_stream_blk_n;
assign inst_idle_sigs[2] = grp_do_qk_gemm_fu_30.do_q_buffer_U0.ap_idle;
assign inst_block_sigs[2] = (grp_do_qk_gemm_fu_30.do_q_buffer_U0.ap_done & ~grp_do_qk_gemm_fu_30.do_q_buffer_U0.ap_continue) | ~grp_do_qk_gemm_fu_30.do_q_buffer_U0.dataflow_in_loop5_U0.pack_gemm_tokens_ap_int_6_32_32_128_8_U0.qq_stream_blk_n | ~grp_do_qk_gemm_fu_30.do_q_buffer_U0.dataflow_in_loop5_U0.pack_gemm_tokens_ap_uint_4_32_32_16_1_U0.qs_stream_blk_n | ~grp_do_qk_gemm_fu_30.do_q_buffer_U0.dataflow_in_loop5_U0.retile_tokens_ap_int_6_32_4_128_8_U0.qq_stream1_blk_n | ~grp_do_qk_gemm_fu_30.do_q_buffer_U0.dataflow_in_loop5_U0.retile_tokens_ap_uint_4_32_4_16_1_U0.qs_stream1_blk_n;
assign inst_idle_sigs[3] = grp_do_qk_gemm_fu_30.do_k_buffer_U0.ap_idle;
assign inst_block_sigs[3] = (grp_do_qk_gemm_fu_30.do_k_buffer_U0.ap_done & ~grp_do_qk_gemm_fu_30.do_k_buffer_U0.ap_continue) | ~grp_do_qk_gemm_fu_30.do_k_buffer_U0.dataflow_in_loop_U0.pack_gemm_tokens_ap_int_6_32_32_128_8_1_U0.kq_stream_blk_n | ~grp_do_qk_gemm_fu_30.do_k_buffer_U0.dataflow_in_loop_U0.pack_gemm_tokens_ap_uint_4_32_32_16_1_2_U0.ks_stream_blk_n | ~grp_do_qk_gemm_fu_30.do_k_buffer_U0.dataflow_in_loop_U0.retile_tokens_ap_int_6_32_8_128_8_U0.kq_stream1_blk_n | ~grp_do_qk_gemm_fu_30.do_k_buffer_U0.dataflow_in_loop_U0.retile_tokens_ap_uint_4_32_8_16_1_U0.ks_stream1_blk_n;
assign inst_idle_sigs[4] = grp_do_qk_gemm_fu_30.do_q_repeat_U0.ap_idle;
assign inst_block_sigs[4] = (grp_do_qk_gemm_fu_30.do_q_repeat_U0.ap_done & ~grp_do_qk_gemm_fu_30.do_q_repeat_U0.ap_continue) | ~grp_do_qk_gemm_fu_30.do_q_repeat_U0.qq_stream1_blk_n | ~grp_do_qk_gemm_fu_30.do_q_repeat_U0.qs_stream1_blk_n | ~grp_do_qk_gemm_fu_30.do_q_repeat_U0.qq_stream2_blk_n | ~grp_do_qk_gemm_fu_30.do_q_repeat_U0.qs_stream2_blk_n;
assign inst_idle_sigs[5] = grp_do_qk_gemm_fu_30.do_k_repeat_U0.ap_idle;
assign inst_block_sigs[5] = (grp_do_qk_gemm_fu_30.do_k_repeat_U0.ap_done & ~grp_do_qk_gemm_fu_30.do_k_repeat_U0.ap_continue) | ~grp_do_qk_gemm_fu_30.do_k_repeat_U0.kq_stream1_blk_n | ~grp_do_qk_gemm_fu_30.do_k_repeat_U0.ks_stream1_blk_n | ~grp_do_qk_gemm_fu_30.do_k_repeat_U0.kq_stream2_blk_n | ~grp_do_qk_gemm_fu_30.do_k_repeat_U0.ks_stream2_blk_n;
assign inst_idle_sigs[6] = grp_do_qk_gemm_fu_30.do_bmm_U0.ap_idle;
assign inst_block_sigs[6] = (grp_do_qk_gemm_fu_30.do_bmm_U0.ap_done & ~grp_do_qk_gemm_fu_30.do_bmm_U0.ap_continue) | ~grp_do_qk_gemm_fu_30.do_bmm_U0.qq_stream2_blk_n | ~grp_do_qk_gemm_fu_30.do_bmm_U0.qs_stream2_blk_n | ~grp_do_qk_gemm_fu_30.do_bmm_U0.kq_stream2_blk_n | ~grp_do_qk_gemm_fu_30.do_bmm_U0.ks_stream2_blk_n;
assign inst_idle_sigs[7] = grp_do_qk_gemm_fu_30.do_q_buffer_U0.dataflow_in_loop5_U0.ap_idle;
assign inst_block_sigs[7] = (grp_do_qk_gemm_fu_30.do_q_buffer_U0.dataflow_in_loop5_U0.ap_done & ~grp_do_qk_gemm_fu_30.do_q_buffer_U0.dataflow_in_loop5_U0.ap_continue);
assign inst_idle_sigs[8] = grp_do_qk_gemm_fu_30.do_q_buffer_U0.dataflow_in_loop5_U0.pack_gemm_tokens_ap_int_6_32_32_128_8_U0.ap_idle;
assign inst_block_sigs[8] = (grp_do_qk_gemm_fu_30.do_q_buffer_U0.dataflow_in_loop5_U0.pack_gemm_tokens_ap_int_6_32_32_128_8_U0.ap_done & ~grp_do_qk_gemm_fu_30.do_q_buffer_U0.dataflow_in_loop5_U0.pack_gemm_tokens_ap_int_6_32_32_128_8_U0.ap_continue);
assign inst_idle_sigs[9] = grp_do_qk_gemm_fu_30.do_q_buffer_U0.dataflow_in_loop5_U0.pack_gemm_tokens_ap_uint_4_32_32_16_1_U0.ap_idle;
assign inst_block_sigs[9] = (grp_do_qk_gemm_fu_30.do_q_buffer_U0.dataflow_in_loop5_U0.pack_gemm_tokens_ap_uint_4_32_32_16_1_U0.ap_done & ~grp_do_qk_gemm_fu_30.do_q_buffer_U0.dataflow_in_loop5_U0.pack_gemm_tokens_ap_uint_4_32_32_16_1_U0.ap_continue);
assign inst_idle_sigs[10] = grp_do_qk_gemm_fu_30.do_q_buffer_U0.dataflow_in_loop5_U0.retile_tokens_ap_int_6_32_4_128_8_U0.ap_idle;
assign inst_block_sigs[10] = (grp_do_qk_gemm_fu_30.do_q_buffer_U0.dataflow_in_loop5_U0.retile_tokens_ap_int_6_32_4_128_8_U0.ap_done & ~grp_do_qk_gemm_fu_30.do_q_buffer_U0.dataflow_in_loop5_U0.retile_tokens_ap_int_6_32_4_128_8_U0.ap_continue);
assign inst_idle_sigs[11] = grp_do_qk_gemm_fu_30.do_q_buffer_U0.dataflow_in_loop5_U0.retile_tokens_ap_uint_4_32_4_16_1_U0.ap_idle;
assign inst_block_sigs[11] = (grp_do_qk_gemm_fu_30.do_q_buffer_U0.dataflow_in_loop5_U0.retile_tokens_ap_uint_4_32_4_16_1_U0.ap_done & ~grp_do_qk_gemm_fu_30.do_q_buffer_U0.dataflow_in_loop5_U0.retile_tokens_ap_uint_4_32_4_16_1_U0.ap_continue);
assign inst_idle_sigs[12] = grp_do_qk_gemm_fu_30.do_k_buffer_U0.dataflow_in_loop_U0.ap_idle;
assign inst_block_sigs[12] = (grp_do_qk_gemm_fu_30.do_k_buffer_U0.dataflow_in_loop_U0.ap_done & ~grp_do_qk_gemm_fu_30.do_k_buffer_U0.dataflow_in_loop_U0.ap_continue);
assign inst_idle_sigs[13] = grp_do_qk_gemm_fu_30.do_k_buffer_U0.dataflow_in_loop_U0.pack_gemm_tokens_ap_int_6_32_32_128_8_1_U0.ap_idle;
assign inst_block_sigs[13] = (grp_do_qk_gemm_fu_30.do_k_buffer_U0.dataflow_in_loop_U0.pack_gemm_tokens_ap_int_6_32_32_128_8_1_U0.ap_done & ~grp_do_qk_gemm_fu_30.do_k_buffer_U0.dataflow_in_loop_U0.pack_gemm_tokens_ap_int_6_32_32_128_8_1_U0.ap_continue);
assign inst_idle_sigs[14] = grp_do_qk_gemm_fu_30.do_k_buffer_U0.dataflow_in_loop_U0.pack_gemm_tokens_ap_uint_4_32_32_16_1_2_U0.ap_idle;
assign inst_block_sigs[14] = (grp_do_qk_gemm_fu_30.do_k_buffer_U0.dataflow_in_loop_U0.pack_gemm_tokens_ap_uint_4_32_32_16_1_2_U0.ap_done & ~grp_do_qk_gemm_fu_30.do_k_buffer_U0.dataflow_in_loop_U0.pack_gemm_tokens_ap_uint_4_32_32_16_1_2_U0.ap_continue);
assign inst_idle_sigs[15] = grp_do_qk_gemm_fu_30.do_k_buffer_U0.dataflow_in_loop_U0.retile_tokens_ap_int_6_32_8_128_8_U0.ap_idle;
assign inst_block_sigs[15] = (grp_do_qk_gemm_fu_30.do_k_buffer_U0.dataflow_in_loop_U0.retile_tokens_ap_int_6_32_8_128_8_U0.ap_done & ~grp_do_qk_gemm_fu_30.do_k_buffer_U0.dataflow_in_loop_U0.retile_tokens_ap_int_6_32_8_128_8_U0.ap_continue);
assign inst_idle_sigs[16] = grp_do_qk_gemm_fu_30.do_k_buffer_U0.dataflow_in_loop_U0.retile_tokens_ap_uint_4_32_8_16_1_U0.ap_idle;
assign inst_block_sigs[16] = (grp_do_qk_gemm_fu_30.do_k_buffer_U0.dataflow_in_loop_U0.retile_tokens_ap_uint_4_32_8_16_1_U0.ap_done & ~grp_do_qk_gemm_fu_30.do_k_buffer_U0.dataflow_in_loop_U0.retile_tokens_ap_uint_4_32_8_16_1_U0.ap_continue);

assign inst_idle_sigs[17] = 1'b0;
assign inst_idle_sigs[18] = grp_do_qk_gemm_fu_30.ap_idle;
assign inst_idle_sigs[19] = grp_do_qk_gemm_fu_30.split_interleaved_heads_ap_int_6_32_32_1_128_8_U0.ap_idle;
assign inst_idle_sigs[20] = grp_do_qk_gemm_fu_30.split_interleaved_heads_ap_uint_4_32_32_1_16_1_U0.ap_idle;
assign inst_idle_sigs[21] = grp_do_qk_gemm_fu_30.do_bmm_U0.ap_idle;

top_hls_deadlock_idx0_monitor top_hls_deadlock_idx0_monitor_U (
    .clock(kernel_monitor_clock),
    .reset(kernel_monitor_reset),
    .axis_block_sigs(axis_block_sigs),
    .inst_idle_sigs(inst_idle_sigs),
    .inst_block_sigs(inst_block_sigs),
    .block(kernel_block)
);

always @ (kernel_block or kernel_monitor_reset) begin
    if (kernel_block == 1'b1 && kernel_monitor_reset == 1'b0) begin
        find_kernel_block = 1'b1;
    end
    else begin
        find_kernel_block = 1'b0;
    end
end
