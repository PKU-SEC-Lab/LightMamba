
wire kernel_monitor_reset;
wire kernel_monitor_clock;
assign kernel_monitor_reset = ~ap_rst_n;
assign kernel_monitor_clock = ap_clk;
wire [3:0] axis_block_sigs;
wire [4:0] inst_idle_sigs;
wire [0:0] inst_block_sigs;
wire kernel_block;

assign axis_block_sigs[0] = ~grp_top_Pipeline_VITIS_LOOP_64_1_VITIS_LOOP_65_2_fu_132.x_stream_TDATA_blk_n;
assign axis_block_sigs[1] = ~grp_top_Pipeline_VITIS_LOOP_81_7_VITIS_LOOP_82_8_fu_139.res_o_stream_TDATA_blk_n;
assign axis_block_sigs[2] = ~grp_top_Pipeline_VITIS_LOOP_125_19_VITIS_LOOP_126_20_fu_146.y_stream_TDATA_blk_n;
assign axis_block_sigs[3] = ~grp_top_Pipeline_VITIS_LOOP_96_12_fu_153.res_i_stream_TDATA_blk_n;

assign inst_block_sigs[0] = 1'b0;

assign inst_idle_sigs[0] = 1'b0;
assign inst_idle_sigs[1] = grp_top_Pipeline_VITIS_LOOP_64_1_VITIS_LOOP_65_2_fu_132.ap_idle;
assign inst_idle_sigs[2] = grp_top_Pipeline_VITIS_LOOP_81_7_VITIS_LOOP_82_8_fu_139.ap_idle;
assign inst_idle_sigs[3] = grp_top_Pipeline_VITIS_LOOP_125_19_VITIS_LOOP_126_20_fu_146.ap_idle;
assign inst_idle_sigs[4] = grp_top_Pipeline_VITIS_LOOP_96_12_fu_153.ap_idle;

top_hls_deadlock_idx0_monitor top_hls_deadlock_idx0_monitor_U (
    .clock(kernel_monitor_clock),
    .reset(kernel_monitor_reset),
    .axis_block_sigs(axis_block_sigs),
    .inst_idle_sigs(inst_idle_sigs),
    .inst_block_sigs(inst_block_sigs),
    .block(kernel_block)
);

always @ (kernel_block or kernel_monitor_reset) begin
    if (kernel_block == 1'b1 && kernel_monitor_reset == 1'b0) begin
        find_kernel_block = 1'b1;
    end
    else begin
        find_kernel_block = 1'b0;
    end
end
