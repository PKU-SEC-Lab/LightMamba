
wire kernel_monitor_reset;
wire kernel_monitor_clock;
assign kernel_monitor_reset = ~ap_rst_n;
assign kernel_monitor_clock = ap_clk;
wire [2:0] axis_block_sigs;
wire [5:0] inst_idle_sigs;
wire [1:0] inst_block_sigs;
wire kernel_block;

assign axis_block_sigs[0] = ~do_rmsnorm_U0.grp_do_rmsnorm_Pipeline_1_fu_64.x_stream_TDATA_blk_n;
assign axis_block_sigs[1] = ~do_quant_U0.xlnq_stream_TDATA_blk_n;
assign axis_block_sigs[2] = ~do_quant_U0.xlns_stream_TDATA_blk_n;

assign inst_idle_sigs[0] = do_rmsnorm_U0.ap_idle;
assign inst_block_sigs[0] = (do_rmsnorm_U0.ap_done & ~do_rmsnorm_U0.ap_continue) | ~do_rmsnorm_U0.grp_do_rmsnorm_Pipeline_1_fu_64.xln_stream_blk_n;
assign inst_idle_sigs[1] = do_quant_U0.ap_idle;
assign inst_block_sigs[1] = (do_quant_U0.ap_done & ~do_quant_U0.ap_continue) | ~do_quant_U0.xln_stream_blk_n;

assign inst_idle_sigs[2] = 1'b0;
assign inst_idle_sigs[3] = do_rmsnorm_U0.ap_idle;
assign inst_idle_sigs[4] = do_rmsnorm_U0.grp_do_rmsnorm_Pipeline_1_fu_64.ap_idle;
assign inst_idle_sigs[5] = do_quant_U0.ap_idle;

top_hls_deadlock_idx0_monitor top_hls_deadlock_idx0_monitor_U (
    .clock(kernel_monitor_clock),
    .reset(kernel_monitor_reset),
    .axis_block_sigs(axis_block_sigs),
    .inst_idle_sigs(inst_idle_sigs),
    .inst_block_sigs(inst_block_sigs),
    .block(kernel_block)
);

always @ (kernel_block or kernel_monitor_reset) begin
    if (kernel_block == 1'b1 && kernel_monitor_reset == 1'b0) begin
        find_kernel_block = 1'b1;
    end
    else begin
        find_kernel_block = 1'b0;
    end
end
