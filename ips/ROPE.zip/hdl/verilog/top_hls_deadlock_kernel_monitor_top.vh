
wire kernel_monitor_reset;
wire kernel_monitor_clock;
assign kernel_monitor_reset = ~ap_rst_n;
assign kernel_monitor_clock = ap_clk;
wire [3:0] axis_block_sigs;
wire [6:0] inst_idle_sigs;
wire [1:0] inst_block_sigs;
wire kernel_block;

assign axis_block_sigs[0] = ~grp_do_rope_fu_32.stage1_cache_cos_sin_U0.grp_stage1_cache_cos_sin_Pipeline_1_fu_34.cos_stream_TDATA_blk_n;
assign axis_block_sigs[1] = ~grp_do_rope_fu_32.stage1_cache_cos_sin_U0.grp_stage1_cache_cos_sin_Pipeline_1_fu_34.sin_stream_TDATA_blk_n;
assign axis_block_sigs[2] = ~grp_do_rope_fu_32.stage2_apply_rotation_U0.qk_stream_TDATA_blk_n;
assign axis_block_sigs[3] = ~grp_do_rope_fu_32.stage2_apply_rotation_U0.rot_stream_TDATA_blk_n;

assign inst_idle_sigs[0] = grp_do_rope_fu_32.stage1_cache_cos_sin_U0.ap_idle;
assign inst_block_sigs[0] = (grp_do_rope_fu_32.stage1_cache_cos_sin_U0.ap_done & ~grp_do_rope_fu_32.stage1_cache_cos_sin_U0.ap_continue) | ~grp_do_rope_fu_32.stage1_cache_cos_sin_U0.grp_stage1_cache_cos_sin_Pipeline_2_fu_44.cos_cache_stream_blk_n | ~grp_do_rope_fu_32.stage1_cache_cos_sin_U0.grp_stage1_cache_cos_sin_Pipeline_2_fu_44.sin_cache_stream_blk_n;
assign inst_idle_sigs[1] = grp_do_rope_fu_32.stage2_apply_rotation_U0.ap_idle;
assign inst_block_sigs[1] = (grp_do_rope_fu_32.stage2_apply_rotation_U0.ap_done & ~grp_do_rope_fu_32.stage2_apply_rotation_U0.ap_continue) | ~grp_do_rope_fu_32.stage2_apply_rotation_U0.cos_cache_stream_blk_n | ~grp_do_rope_fu_32.stage2_apply_rotation_U0.sin_cache_stream_blk_n;

assign inst_idle_sigs[2] = 1'b0;
assign inst_idle_sigs[3] = grp_do_rope_fu_32.ap_idle;
assign inst_idle_sigs[4] = grp_do_rope_fu_32.stage1_cache_cos_sin_U0.ap_idle;
assign inst_idle_sigs[5] = grp_do_rope_fu_32.stage1_cache_cos_sin_U0.grp_stage1_cache_cos_sin_Pipeline_1_fu_34.ap_idle;
assign inst_idle_sigs[6] = grp_do_rope_fu_32.stage2_apply_rotation_U0.ap_idle;

top_hls_deadlock_idx0_monitor top_hls_deadlock_idx0_monitor_U (
    .clock(kernel_monitor_clock),
    .reset(kernel_monitor_reset),
    .axis_block_sigs(axis_block_sigs),
    .inst_idle_sigs(inst_idle_sigs),
    .inst_block_sigs(inst_block_sigs),
    .block(kernel_block)
);

always @ (kernel_block or kernel_monitor_reset) begin
    if (kernel_block == 1'b1 && kernel_monitor_reset == 1'b0) begin
        find_kernel_block = 1'b1;
    end
    else begin
        find_kernel_block = 1'b0;
    end
end
