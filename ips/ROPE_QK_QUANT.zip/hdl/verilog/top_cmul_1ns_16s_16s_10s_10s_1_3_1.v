// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2022.1 (64-bit)
// Tool Version Limit: 2022.04
// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// ==============================================================
`timescale 1 ns / 1 ps

(* keep_hierarchy="yes" *)module top_cmul_1ns_16s_16s_10s_10s_1_3_1 (clk,reset,ce,din0, din2, din1, din3, dout_0, dout_1);

parameter ID = 1;
parameter NUM_STAGE = 1;
parameter din0_WIDTH = 18;
parameter din1_WIDTH = 18;
parameter din2_WIDTH = 18;
parameter din3_WIDTH = 18;

parameter dout_0_WIDTH = 58;
parameter dout_1_WIDTH = 58;

input clk;
input reset;
input ce;
input signed [din0_WIDTH-1:0] din0;
input signed [din1_WIDTH-1:0] din1;
input signed [din2_WIDTH-1:0] din2;
input signed [din3_WIDTH-1:0] din3;

output signed [dout_0_WIDTH-1:0] dout_0;
output signed [dout_1_WIDTH-1:0] dout_1;

reg signed [din0_WIDTH-1:0] din0_reg;
reg signed [din1_WIDTH-1:0] din1_reg;
reg signed [din2_WIDTH-1:0] din2_reg;
reg signed [din3_WIDTH-1:0] din3_reg;

reg signed [din0_WIDTH+din2_WIDTH:0] common;
reg signed [din0_WIDTH+din2_WIDTH:0] prod2;
reg signed [din0_WIDTH+din2_WIDTH:0] prod3;

wire signed [din0_WIDTH:0] tmp1;
wire signed [din2_WIDTH:0] tmp2;
wire signed [din2_WIDTH:0] tmp3;

assign tmp1 = din0_reg - din1_reg;
assign tmp2 = din2_reg - din3_reg;
assign tmp3 = din2_reg + din3_reg;

always @ (posedge clk) begin
    din0_reg <= din0;
    din1_reg <= din1;
    din2_reg <= din2;
    din3_reg <= din3;
    common <= din3_reg * tmp1;
    prod2  <= din0_reg * tmp2;
    prod3  <= din1_reg * tmp3;
end

assign dout_1 = common + prod3;
assign dout_0 = common + prod2;

endmodule
