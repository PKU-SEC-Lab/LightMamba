-- ==============================================================
-- Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2022.1 (64-bit)
-- Tool Version Limit: 2022.04
-- Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
-- ==============================================================
library IEEE;
use IEEE.STD_LOGIC_1164.all;
use IEEE.NUMERIC_STD.all;

entity top_cmul_1ns_16s_16s_10s_10s_1_3_1 is
    generic (
        ID           : INTEGER := 1;
        NUM_STAGE    : INTEGER := 1; 
        din0_WIDTH   : INTEGER := 18;
        din1_WIDTH   : INTEGER := 18;
        din2_WIDTH   : INTEGER := 18;
        din3_WIDTH   : INTEGER := 18;
        dout_0_WIDTH : INTEGER := 58;
        dout_1_WIDTH : INTEGER := 58
        );
    port (
        clk    : in  STD_LOGIC;
        reset  : in  STD_LOGIC;
        ce     : in  STD_LOGIC;
        din0   : in  STD_LOGIC_VECTOR (din0_WIDTH-1 downto 0);
        din1   : in  STD_LOGIC_VECTOR (din1_WIDTH-1 downto 0);
        din2   : in  STD_LOGIC_VECTOR (din2_WIDTH-1 downto 0);
        din3   : in  STD_LOGIC_VECTOR (din3_WIDTH-1 downto 0);
        dout_0 : out STD_LOGIC_VECTOR (dout_0_WIDTH-1 downto 0);
        dout_1 : out STD_LOGIC_VECTOR (dout_1_WIDTH-1 downto 0)
    );
    attribute keep_hierarchy : string;
    attribute keep_hierarchy of top_cmul_1ns_16s_16s_10s_10s_1_3_1 : entity is "yes";
end entity top_cmul_1ns_16s_16s_10s_10s_1_3_1;

architecture behav of top_cmul_1ns_16s_16s_10s_10s_1_3_1 is 
    signal din0_reg     : STD_LOGIC_VECTOR (din0_WIDTH-1 downto 0);
    signal din1_reg     : STD_LOGIC_VECTOR (din1_WIDTH-1 downto 0);
    signal din2_reg     : STD_LOGIC_VECTOR (din2_WIDTH-1 downto 0);
    signal din3_reg     : STD_LOGIC_VECTOR (din3_WIDTH-1 downto 0);
    signal tmp1         : signed (din0_WIDTH downto 0);
    signal tmp2         : signed (din2_WIDTH downto 0);
    signal tmp3         : signed (din2_WIDTH downto 0);
    signal common       : signed (din0_WIDTH+din2_WIDTH downto 0);
    signal prod2        : signed (din0_WIDTH+din2_WIDTH downto 0);
    signal prod3        : signed (din0_WIDTH+din2_WIDTH downto 0);
    signal common_reg   : signed (din0_WIDTH+din2_WIDTH downto 0);
    signal prod2_reg    : signed (din0_WIDTH+din2_WIDTH downto 0);
    signal prod3_reg    : signed (din0_WIDTH+din2_WIDTH downto 0);
    signal dout0_58     : signed (57 downto 0);
    signal dout1_58     : signed (57 downto 0);
begin
    tmp1     <= resize(signed(din0_reg),din0_WIDTH+1) - resize(signed(din1_reg),din1_WIDTH+1);
    tmp2     <= resize(signed(din2_reg),din2_WIDTH+1) - resize(signed(din3_reg),din3_WIDTH+1);
    tmp3     <= resize(signed(din2_reg),din2_WIDTH+1) + resize(signed(din3_reg),din3_WIDTH+1);
    common   <= signed(din3_reg) * tmp1;
    prod2    <= signed(din0_reg) * tmp2;
    prod3    <= signed(din1_reg) * tmp3;
    dout0_58 <= resize(common_reg,58) + resize(prod2_reg,58);
    dout1_58 <= resize(common_reg,58) + resize(prod3_reg,58);
    dout_0   <= std_logic_vector(resize(dout0_58,dout_0_WIDTH));
    dout_1   <= std_logic_vector(resize(dout1_58,dout_1_WIDTH));

reg_proc : process(clk)
begin
    if (clk'event and clk = '1') then
        din0_reg   <= din0;
        din1_reg   <= din1;
        din2_reg   <= din2;
        din3_reg   <= din3;
        common_reg <= common;
        prod2_reg  <= prod2;
        prod3_reg  <= prod3;
    end if;
end process;
end architecture behav;
