-- ==============================================================
-- Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2022.1 (64-bit)
-- Tool Version Limit: 2022.04
-- Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
-- ==============================================================
library ieee; 
use ieee.std_logic_1164.all; 
use ieee.std_logic_unsigned.all;

entity top_stage1_preprocess_p_ZL11ROPE_THETAS_0_ROM_AUTO_1R is 
    generic(
             DataWidth     : integer := 25; 
             AddressWidth     : integer := 5; 
             AddressRange    : integer := 32
    ); 
    port (
          address0      : in std_logic_vector(AddressWidth-1 downto 0); 
          ce0       : in std_logic; 
          q0         : out std_logic_vector(DataWidth-1 downto 0);
          address1      : in std_logic_vector(AddressWidth-1 downto 0); 
          ce1       : in std_logic; 
          q1         : out std_logic_vector(DataWidth-1 downto 0);
          reset     : in std_logic;
          clk       : in std_logic
    ); 
end entity; 


architecture rtl of top_stage1_preprocess_p_ZL11ROPE_THETAS_0_ROM_AUTO_1R is 

signal address0_tmp : std_logic_vector(AddressWidth-1 downto 0); 
signal address1_tmp : std_logic_vector(AddressWidth-1 downto 0); 
type mem_array is array (0 to AddressRange-1) of std_logic_vector (DataWidth-1 downto 0); 
signal mem : mem_array := (
    0 => "1000000000000000000000000", 1 => "0101111111111100100010001", 
    2 => "0100011111111010110011001", 3 => "0011010111111010001001101", 
    4 => "0010100001111010001001101", 5 => "0001111001011010100001000", 
    6 => "0001011011000011000100001", 7 => "0001000100010001101011101", 
    8 => "0000110011001100110011001", 9 => "0000100110011001010000001", 
    10 => "0000011100110010101011100", 11 => "0000010101100101110100001", 
    12 => "0000010000001100001101110", 13 => "0000001100001001000011010", 
    14 => "0000001001000110101101001", 15 => "0000000110110100111101111", 
    16 => "0000000101000111101011100", 17 => "0000000011110101101110011", 
    18 => "0000000010111000010001001", 19 => "0000000010001010001011100", 
    20 => "0000000001100111100111110", 21 => "0000000001001101101101001", 
    22 => "0000000000111010010001010", 23 => "0000000000101011101100100", 
    24 => "0000000000100000110001001", 25 => "0000000000011000100100101", 
    26 => "0000000000010010011011010", 27 => "0000000000001101110100010", 
    28 => "0000000000001010010111001", 29 => "0000000000000111110001010", 
    30 => "0000000000000101110100111", 31 => "0000000000000100010111101" );


begin 


memory_access_guard_0: process (address0) 
begin
      address0_tmp <= address0;
--synthesis translate_off
      if (CONV_INTEGER(address0) > AddressRange-1) then
           address0_tmp <= (others => '0');
      else 
           address0_tmp <= address0;
      end if;
--synthesis translate_on
end process;

memory_access_guard_1: process (address1) 
begin
      address1_tmp <= address1;
--synthesis translate_off
      if (CONV_INTEGER(address1) > AddressRange-1) then
           address1_tmp <= (others => '0');
      else 
           address1_tmp <= address1;
      end if;
--synthesis translate_on
end process;

p_rom_access: process (clk)  
begin 
    if (clk'event and clk = '1') then
        if (ce0 = '1') then 
            q0 <= mem(CONV_INTEGER(address0_tmp)); 
        end if;
        if (ce1 = '1') then 
            q1 <= mem(CONV_INTEGER(address1_tmp)); 
        end if;
    end if;
end process;

end rtl;

