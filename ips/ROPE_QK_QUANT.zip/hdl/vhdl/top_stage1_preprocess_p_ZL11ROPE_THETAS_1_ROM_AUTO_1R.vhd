-- ==============================================================
-- Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2022.1 (64-bit)
-- Tool Version Limit: 2022.04
-- Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
-- ==============================================================
library ieee; 
use ieee.std_logic_1164.all; 
use ieee.std_logic_unsigned.all;

entity top_stage1_preprocess_p_ZL11ROPE_THETAS_1_ROM_AUTO_1R is 
    generic(
             DataWidth     : integer := 24; 
             AddressWidth     : integer := 5; 
             AddressRange    : integer := 32
    ); 
    port (
          address0      : in std_logic_vector(AddressWidth-1 downto 0); 
          ce0       : in std_logic; 
          q0         : out std_logic_vector(DataWidth-1 downto 0);
          address1      : in std_logic_vector(AddressWidth-1 downto 0); 
          ce1       : in std_logic; 
          q1         : out std_logic_vector(DataWidth-1 downto 0);
          reset     : in std_logic;
          clk       : in std_logic
    ); 
end entity; 


architecture rtl of top_stage1_preprocess_p_ZL11ROPE_THETAS_1_ROM_AUTO_1R is 

signal address0_tmp : std_logic_vector(AddressWidth-1 downto 0); 
signal address1_tmp : std_logic_vector(AddressWidth-1 downto 0); 
type mem_array is array (0 to AddressRange-1) of std_logic_vector (DataWidth-1 downto 0); 
signal mem : mem_array := (
    0 => "110111011010111111010110", 1 => "101001100011110111011111", 
    2 => "011111001010100111100111", 3 => "010111010111110000001101", 
    4 => "010001100001101010000001", 5 => "001101001001000111111011", 
    6 => "001001110110110000001111", 7 => "000111011000111111111010", 
    8 => "000101100010101100101111", 9 => "000100001001111111001001", 
    10 => "000011000111011101100011", 11 => "000010010101100100110100", 
    12 => "000001110000001010100110", 13 => "000001010100000111001100", 
    14 => "000000111111000100110100", 15 => "000000101111010011001100", 
    16 => "000000100011011110000100", 17 => "000000011010100110010100", 
    18 => "000000010011111100100011", 19 => "000000001110111101010010", 
    20 => "000000001011001101110111", 21 => "000000001000011010010100", 
    22 => "000000000110010011101011", 23 => "000000000100101110101110", 
    24 => "000000000011100011000000", 25 => "000000000010101010001110", 
    26 => "000000000001111111101001", 27 => "000000000001011111101110", 
    28 => "000000000001000111110010", 29 => "000000000000110101110101", 
    30 => "000000000000101000010111", 31 => "000000000000011110010001" );


begin 


memory_access_guard_0: process (address0) 
begin
      address0_tmp <= address0;
--synthesis translate_off
      if (CONV_INTEGER(address0) > AddressRange-1) then
           address0_tmp <= (others => '0');
      else 
           address0_tmp <= address0;
      end if;
--synthesis translate_on
end process;

memory_access_guard_1: process (address1) 
begin
      address1_tmp <= address1;
--synthesis translate_off
      if (CONV_INTEGER(address1) > AddressRange-1) then
           address1_tmp <= (others => '0');
      else 
           address1_tmp <= address1;
      end if;
--synthesis translate_on
end process;

p_rom_access: process (clk)  
begin 
    if (clk'event and clk = '1') then
        if (ce0 = '1') then 
            q0 <= mem(CONV_INTEGER(address0_tmp)); 
        end if;
        if (ce1 = '1') then 
            q1 <= mem(CONV_INTEGER(address1_tmp)); 
        end if;
    end if;
end process;

end rtl;

