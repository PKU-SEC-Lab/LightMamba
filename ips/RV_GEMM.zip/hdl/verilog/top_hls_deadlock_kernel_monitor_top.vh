
wire kernel_monitor_reset;
wire kernel_monitor_clock;
assign kernel_monitor_reset = ~ap_rst_n;
assign kernel_monitor_clock = ap_clk;
wire [4:0] axis_block_sigs;
wire [19:0] inst_idle_sigs;
wire [12:0] inst_block_sigs;
wire kernel_block;

assign axis_block_sigs[0] = ~do_rv_gemm_U0.do_r_repeat_U0.rq_stream_TDATA_blk_n;
assign axis_block_sigs[1] = ~do_rv_gemm_U0.do_r_repeat_U0.rs_stream_TDATA_blk_n;
assign axis_block_sigs[2] = ~do_rv_gemm_U0.do_v_transpose_U0.grp_pack_gemm_tokens_ap_int_26_32_32_128_8_s_fu_44.v_stream_TDATA_blk_n;
assign axis_block_sigs[3] = ~do_adapt_2_U0.aq_stream_TDATA_blk_n;
assign axis_block_sigs[4] = ~do_adapt_U0.as_stream_TDATA_blk_n;

assign inst_idle_sigs[0] = do_rv_gemm_U0.ap_idle;
assign inst_block_sigs[0] = (do_rv_gemm_U0.ap_done & ~do_rv_gemm_U0.ap_continue) | ~do_rv_gemm_U0.do_r_repeat_U0.rq_stream13_blk_n | ~do_rv_gemm_U0.do_r_repeat_U0.rs_stream1_blk_n;
assign inst_idle_sigs[1] = do_adapt_5_U0.ap_idle;
assign inst_block_sigs[1] = (do_adapt_5_U0.ap_done & ~do_adapt_5_U0.ap_continue) | ~do_rv_gemm_U0.do_v_transpose_U0.grp_transpose_tokens_ap_int_26_32_8_128_8_s_fu_51.v_stream_trans_blk_n;
assign inst_idle_sigs[2] = do_quant_1_U0.ap_idle;
assign inst_block_sigs[2] = (do_quant_1_U0.ap_done & ~do_quant_1_U0.ap_continue) | ~do_rv_gemm_U0.do_adapt_4_U0.v_stream_trans_blk_n | ~do_rv_gemm_U0.do_adapt_4_U0.v_stream_trans_adpt_blk_n;
assign inst_idle_sigs[3] = do_adapt_2_U0.ap_idle;
assign inst_block_sigs[3] = (do_adapt_2_U0.ap_done & ~do_adapt_2_U0.ap_continue) | ~do_rv_gemm_U0.do_quant_U0.v_stream_trans_adpt_blk_n | ~do_rv_gemm_U0.do_quant_U0.vq_stream_adpt_blk_n | ~do_rv_gemm_U0.do_quant_U0.vs_stream_adpt_blk_n;
assign inst_idle_sigs[4] = do_adapt_U0.ap_idle;
assign inst_block_sigs[4] = (do_adapt_U0.ap_done & ~do_adapt_U0.ap_continue) | ~do_rv_gemm_U0.do_adapt_3_U0.vq_stream_adpt_blk_n | ~do_rv_gemm_U0.do_adapt_3_U0.vq_stream1_blk_n;
assign inst_idle_sigs[5] = do_rv_gemm_U0.do_r_repeat_U0.ap_idle;
assign inst_block_sigs[5] = (do_rv_gemm_U0.do_r_repeat_U0.ap_done & ~do_rv_gemm_U0.do_r_repeat_U0.ap_continue) | ~do_rv_gemm_U0.do_adapt_1_U0.vs_stream_adpt_blk_n | ~do_rv_gemm_U0.do_adapt_1_U0.vs_stream1_blk_n;
assign inst_idle_sigs[6] = do_rv_gemm_U0.do_v_transpose_U0.ap_idle;
assign inst_block_sigs[6] = (do_rv_gemm_U0.do_v_transpose_U0.ap_done & ~do_rv_gemm_U0.do_v_transpose_U0.ap_continue) | ~do_rv_gemm_U0.do_v_repeat_U0.vq_stream1_blk_n | ~do_rv_gemm_U0.do_v_repeat_U0.vs_stream1_blk_n | ~do_rv_gemm_U0.do_v_repeat_U0.vq_stream2_blk_n | ~do_rv_gemm_U0.do_v_repeat_U0.vs_stream2_blk_n;
assign inst_idle_sigs[7] = do_rv_gemm_U0.do_adapt_4_U0.ap_idle;
assign inst_block_sigs[7] = (do_rv_gemm_U0.do_adapt_4_U0.ap_done & ~do_rv_gemm_U0.do_adapt_4_U0.ap_continue) | ~do_rv_gemm_U0.do_bmm_U0.rq_stream1_blk_n | ~do_rv_gemm_U0.do_bmm_U0.rs_stream1_blk_n | ~do_rv_gemm_U0.do_bmm_U0.vq_stream2_blk_n | ~do_rv_gemm_U0.do_bmm_U0.vs_stream2_blk_n | ~do_rv_gemm_U0.do_bmm_U0.a_stream1_blk_n;
assign inst_idle_sigs[8] = do_rv_gemm_U0.do_quant_U0.ap_idle;
assign inst_block_sigs[8] = (do_rv_gemm_U0.do_quant_U0.ap_done & ~do_rv_gemm_U0.do_quant_U0.ap_continue) | ~do_rv_gemm_U0.do_bmm_U0.a_stream1_blk_n;
assign inst_idle_sigs[9] = do_rv_gemm_U0.do_adapt_3_U0.ap_idle;
assign inst_block_sigs[9] = (do_rv_gemm_U0.do_adapt_3_U0.ap_done & ~do_rv_gemm_U0.do_adapt_3_U0.ap_continue) | ~do_adapt_5_U0.a_stream_blk_n | ~do_adapt_5_U0.a_stream_adpt_blk_n;
assign inst_idle_sigs[10] = do_rv_gemm_U0.do_adapt_1_U0.ap_idle;
assign inst_block_sigs[10] = (do_rv_gemm_U0.do_adapt_1_U0.ap_done & ~do_rv_gemm_U0.do_adapt_1_U0.ap_continue) | ~do_quant_1_U0.a_stream_adpt_blk_n | ~do_quant_1_U0.aq_stream_adpt_blk_n | ~do_quant_1_U0.as_stream_adpt_blk_n;
assign inst_idle_sigs[11] = do_rv_gemm_U0.do_v_repeat_U0.ap_idle;
assign inst_block_sigs[11] = (do_rv_gemm_U0.do_v_repeat_U0.ap_done & ~do_rv_gemm_U0.do_v_repeat_U0.ap_continue) | ~do_adapt_2_U0.aq_stream_adpt_blk_n;
assign inst_idle_sigs[12] = do_rv_gemm_U0.do_bmm_U0.ap_idle;
assign inst_block_sigs[12] = (do_rv_gemm_U0.do_bmm_U0.ap_done & ~do_rv_gemm_U0.do_bmm_U0.ap_continue) | ~do_adapt_U0.as_stream_adpt_blk_n;

assign inst_idle_sigs[13] = 1'b0;
assign inst_idle_sigs[14] = do_rv_gemm_U0.ap_idle;
assign inst_idle_sigs[15] = do_rv_gemm_U0.do_r_repeat_U0.ap_idle;
assign inst_idle_sigs[16] = do_rv_gemm_U0.do_v_transpose_U0.ap_idle;
assign inst_idle_sigs[17] = do_rv_gemm_U0.do_v_transpose_U0.grp_pack_gemm_tokens_ap_int_26_32_32_128_8_s_fu_44.ap_idle;
assign inst_idle_sigs[18] = do_adapt_2_U0.ap_idle;
assign inst_idle_sigs[19] = do_adapt_U0.ap_idle;

top_hls_deadlock_idx0_monitor top_hls_deadlock_idx0_monitor_U (
    .clock(kernel_monitor_clock),
    .reset(kernel_monitor_reset),
    .axis_block_sigs(axis_block_sigs),
    .inst_idle_sigs(inst_idle_sigs),
    .inst_block_sigs(inst_block_sigs),
    .block(kernel_block)
);

always @ (kernel_block or kernel_monitor_reset) begin
    if (kernel_block == 1'b1 && kernel_monitor_reset == 1'b0) begin
        find_kernel_block = 1'b1;
    end
    else begin
        find_kernel_block = 1'b0;
    end
end
