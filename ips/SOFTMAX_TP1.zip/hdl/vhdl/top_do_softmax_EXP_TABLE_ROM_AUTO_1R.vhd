-- ==============================================================
-- Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2022.1 (64-bit)
-- Tool Version Limit: 2022.04
-- Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
-- ==============================================================
library ieee; 
use ieee.std_logic_1164.all; 
use ieee.std_logic_unsigned.all;

entity top_do_softmax_EXP_TABLE_ROM_AUTO_1R is 
    generic(
             DataWidth     : integer := 8; 
             AddressWidth     : integer := 8; 
             AddressRange    : integer := 256
    ); 
    port (
          address0      : in std_logic_vector(AddressWidth-1 downto 0); 
          ce0       : in std_logic; 
          q0         : out std_logic_vector(DataWidth-1 downto 0);
          reset     : in std_logic;
          clk       : in std_logic
    ); 
end entity; 


architecture rtl of top_do_softmax_EXP_TABLE_ROM_AUTO_1R is 

signal address0_tmp : std_logic_vector(AddressWidth-1 downto 0); 
type mem_array is array (0 to AddressRange-1) of std_logic_vector (DataWidth-1 downto 0); 
signal mem : mem_array := (
    0 => "11111111", 1 => "11101010", 2 => "11010111", 3 => "11000100", 
    4 => "10110100", 5 => "10100101", 6 => "10010111", 7 => "10001010", 
    8 => "01111110", 9 => "01110100", 10 => "01101010", 11 => "01100001", 
    12 => "01011001", 13 => "01010001", 14 => "01001010", 15 => "01000100", 
    16 => "00111110", 17 => "00111001", 18 => "00110100", 19 => "00110000", 
    20 => "00101100", 21 => "00101000", 22 => "00100101", 23 => "00100010", 
    24 => "00011111", 25 => "00011100", 26 => "00011010", 27 => "00011000", 
    28 => "00010110", 29 => "00010100", 30 => "00010010", 31 => "00010001", 
    32 => "00001111", 33 => "00001110", 34 => "00001101", 35 => "00001100", 
    36 => "00001011", 37 => "00001010", 38 => "00001001", 39 => "00001000", 
    40 to 41=> "00000111", 42 to 43=> "00000110", 44 to 45=> "00000101", 46 to 48=> "00000100", 
    49 to 52=> "00000011", 53 to 58=> "00000010", 59 to 70=> "00000001", 71 to 255=> "00000000" );


begin 


memory_access_guard_0: process (address0) 
begin
      address0_tmp <= address0;
--synthesis translate_off
      if (CONV_INTEGER(address0) > AddressRange-1) then
           address0_tmp <= (others => '0');
      else 
           address0_tmp <= address0;
      end if;
--synthesis translate_on
end process;

p_rom_access: process (clk)  
begin 
    if (clk'event and clk = '1') then
        if (ce0 = '1') then 
            q0 <= mem(CONV_INTEGER(address0_tmp)); 
        end if;
    end if;
end process;

end rtl;

